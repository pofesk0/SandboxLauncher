package ex.sandbox.launcher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;

public class SandboxAccessibilityService extends AccessibilityService {

    private BroadcastReceiver screenReceiver;
    private boolean waitForUnlock = false;

    private String lastForegroundPackage = null;
    private String preAllowedPackage = null;

    // ================================
    // ❌ ИГНОРИРУЕМЫЕ ПАКЕТЫ
    // ================================
    private static final String[] IGNORED_PACKAGES = {
		"android",
		"com.android.systemui",

		// Xiaomi / HyperOS / MIUI
		"com.miui",
		"com.miui.securitycenter",
		"com.miui.systemui",
		"com.miui.guardprovider",

		// Realme / Oppo / ColorOS
		"com.realme",
		"com.coloros",
		"com.oppo",
		"com.heytap",

		// Samsung / OneUI
		"com.samsung",
		"com.sec.android",

		// Huawei / EMUI
		"com.huawei",

		// Google
		"com.google.android.permissioncontroller",
		"com.google.android.systemui"
    };

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();

        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 0;
        setServiceInfo(info);

        screenReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                    waitForUnlock = true;
                }
            }
        };

        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        registerReceiver(screenReceiver, f);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {

        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            return;
        }

        if (event.getPackageName() == null) {
            return;
        }

        String pkg = event.getPackageName().toString();

        // ================================
        // ❌ ИГНОРИРУЕМ SYSTEM / OEM UI
        // ================================
        if (isIgnoredPackage(pkg)) {
            return;
        }

        if (isSystemUiClass(event.getClassName())) {
            return;
        }

        if (Build.VERSION.SDK_INT >= 21) {
            int changes = event.getWindowChanges();
            if ((changes & AccessibilityEvent.WINDOWS_CHANGE_REMOVED) != 0) {
                return;
            }
        }

        // ================================
        // ❌ ИГНОРИРУЕМ АКТИВНУЮ КЛАВИАТУРУ
        // ================================
        String ime = Settings.Secure.getString(
			getContentResolver(),
			Settings.Secure.DEFAULT_INPUT_METHOD
        );
        if (ime != null) {
            int slash = ime.indexOf('/');
            if (slash > 0 && ime.substring(0, slash).equals(pkg)) {
                return;
            }
        }

        // ================================
        // 🔓 ПРОВЕРКА UNLOCK
        // ================================
        KeyguardManager km =
			(KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        boolean unlocked = km != null && !km.isKeyguardLocked();

        // ================================
        // 1. SCREEN_ON → ЖДЁМ UNLOCK
        // ================================
        if (waitForUnlock) {
            if (!unlocked) {
                return;
            }

            waitForUnlock = false;

            MainActivity.lastPackage = "abcd123";
            preAllowedPackage = null;
            lastForegroundPackage = null;

            performGlobalAction(GLOBAL_ACTION_HOME);
            return;
        }

        // ================================
        // 2. АБСОЛЮТНЫЙ РЕЖИМ
        // ================================
        if ("abcd123".equals(MainActivity.lastPackage)) {
            if (unlocked) {
                performGlobalAction(GLOBAL_ACTION_HOME);
            }
            return;
        }

        // ================================
        // 3. PREALLOWED — ОДИН ПАКЕТ
        // ================================
        if ("PreAllowed".equals(MainActivity.lastPackage)) {

            if (preAllowedPackage == null && !pkg.equals(getPackageName())) {
                preAllowedPackage = pkg;
                lastForegroundPackage = pkg;
                return;
            }

            if (pkg.equals(preAllowedPackage)) {
                lastForegroundPackage = pkg;
                return;
            }

            MainActivity.lastPackage = "abcd123";
            preAllowedPackage = null;
            lastForegroundPackage = null;

            if (unlocked) {
                performGlobalAction(GLOBAL_ACTION_HOME);
            }
            return;
        }

        // ================================
        // 4. ВОЗВРАТ В ЛАУНЧЕР
        // ================================
        if (pkg.equals(getPackageName())) {
            preAllowedPackage = null;
            lastForegroundPackage = pkg;
            return;
        }

        // ================================
        // 5. ОБЫЧНЫЙ РЕЖИМ
        // ================================
        lastForegroundPackage = pkg;
    }

    @Override
    public void onInterrupt() {
        // не требуется
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (screenReceiver != null) {
            unregisterReceiver(screenReceiver);
            screenReceiver = null;
        }
    }

    // ================================
    // 🧠 ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ================================
    private boolean isIgnoredPackage(String pkg) {
        for (String ignored : IGNORED_PACKAGES) {
            if (pkg.equals(ignored) || pkg.startsWith(ignored + ".")) {
                return true;
            }
        }
        return false;
    }

    private boolean isSystemUiClass(CharSequence className) {
        if (className == null) return false;

        String cls = className.toString();
        return cls.contains("StatusBar")
			|| cls.contains("NavigationBar")
			|| cls.contains("Keyguard")
			|| cls.contains("SystemUI")
		
			|| cls.contains("GlobalActions")
			|| cls.contains("VolumeDialog")
			|| cls.contains("Notification")
			|| cls.contains("PowerMenu");
    }
}
