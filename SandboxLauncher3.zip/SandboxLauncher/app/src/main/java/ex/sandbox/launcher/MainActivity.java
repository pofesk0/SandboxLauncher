package ex.sandbox.launcher;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

	public static String lastPackage = "abcd123";

	private SharedPreferences prefs;    
	private Set<String> whitelist;    
	private android.app.AlertDialog accessibilityDialog;
	private PackageManager pm;    
    private String accessCode;
	private boolean showed=false;
	private LinearLayout rootLayout;    
	private GridLayout grid;    

	private Map<String, LinearLayout> appTiles = new HashMap<>();    

	@Override    
	protected void onCreate(Bundle savedInstanceState) {    
		super.onCreate(savedInstanceState);    

		pm = getPackageManager();    
		prefs = getSharedPreferences("sandbox_prefs", MODE_PRIVATE);    
		whitelist = new HashSet<>(prefs.getStringSet("whitelist", new HashSet<String>()));    

		rootLayout = new LinearLayout(this);    
		rootLayout.setOrientation(LinearLayout.VERTICAL);    

		ScrollView scrollView = new ScrollView(this);    
		grid = new GridLayout(this);    
		grid.setColumnCount(4);    

		scrollView.addView(grid);    
		rootLayout.addView(scrollView);    

		setContentView(rootLayout);    


	}

	@Override
	protected void onPause()
	{
		super.onPause();
		if (lastPackage!="allowed" && lastPackage!="PreAllowed"){
			lastPackage ="abcd123";}
	}  



	@Override
	public void onBackPressed() {
		if (showed==false){
			showMainScreen();}
	}


	@Override
	protected void onResume() {
		super.onResume();
		lastPackage = "abcd123";

		PackageManager pm = getPackageManager();

		// =======================
		// 1. ПРОВЕРКА ЛАУНЧЕРА
		// =======================
		Intent homeIntent = new Intent(Intent.ACTION_MAIN);
		homeIntent.addCategory(Intent.CATEGORY_HOME);

		ResolveInfo ri = pm.resolveActivity(
            homeIntent,
            PackageManager.MATCH_DEFAULT_ONLY
		);

		boolean isDefaultLauncher =
            ri != null &&
            ri.activityInfo != null &&
            ri.activityInfo.packageName.equals(getApplicationContext().getPackageName());

		if (!isDefaultLauncher) {
			try {
				startActivity(
                    new Intent(android.provider.Settings.ACTION_HOME_SETTINGS)
				);
			} catch (Exception e) {
				startActivity(
                    new Intent(
						android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS
                    )
				);
			}
			return;
		}

		// =======================
		// 2. ПРОВЕРКА ACCESSIBILITY (КАНОН)
		// =======================
		boolean accessibilityEnabled = false;
		

		try {
			int enabled = android.provider.Settings.Secure.getInt(
                getContentResolver(),
                android.provider.Settings.Secure.ACCESSIBILITY_ENABLED
			);

			if (enabled == 1) {
				String services = android.provider.Settings.Secure.getString(
                    getContentResolver(),
                    android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
				);

				if (services != null) {
					String myService =
                        new android.content.ComponentName(
						this,
						SandboxAccessibilityService.class
					).flattenToString();

					accessibilityEnabled = services.contains(myService);
				}
			}
		} catch (Exception ignored) {}

		// =======================
		// 3. ЕСЛИ ВКЛЮЧЕНЫ → УБРАТЬ ОКНО
		// =======================
		boolean skipAccessibility =
			prefs.getBoolean("skip_accessibility", false);
		
		if (accessibilityEnabled || skipAccessibility) {
			if (accessibilityDialog != null && accessibilityDialog.isShowing()) {
				accessibilityDialog.dismiss();
				accessibilityDialog = null;
			}
			showMainScreen();
			return;
		}

		// =======================
		// 4. ЕСЛИ НЕ ВКЛЮЧЕНЫ → ПОКАЗАТЬ ОДИН РАЗ
		// =======================
		if (accessibilityDialog != null && accessibilityDialog.isShowing()) {
			return; // уже показано
		}

		// ---------- UI ----------
		final LinearLayout root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

		LinearLayout.LayoutParams lp =
            new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT
		);
		lp.bottomMargin = dpToPx(12);

		TextView t1 = new TextView(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			t1.setText("Дайте приложению спецвозможности. Это нужно чтобы возвращаться домой когда приложения открыты в обход лаунчера, а также после включения экрана. Это нужно чтобы лучше защитить скрытые приложения.");
		} else {t1.setText(
				"Grant the accessibility permission to the application. This is required to return to the home screen when applications are opened bypassing the launcher, as well as after the screen is turned on. This is required to better protect hidden applications."
			);
	}
		root.addView(t1, lp);

		TextView t2 = new TextView(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			t2.setText("Перейдите в настройки спецвозможностей и там включите их для нашего приложения.");
		} else {
			t2.setText("Go to the accessibility settings and enable them for our application.");
		}
		root.addView(t2, lp);

		Button b1 = new Button(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			b1.setText("Перейти в настройки спецвозможностей");
		} else {
			b1.setText("Open accessibility settings");
		}
		root.addView(b1, lp);
		b1.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					startActivity(
						new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
					);
				}
			});

		TextView t3 = new TextView(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			t3.setText("Если вам в настройках спецвозможностей сказали, что это ограниченная настройка, то перейдите в настройки приложения, нажмите три точки в правом верхнем углу и затем нажмите разрешить ограниченные настройки.");
		} else {
			t3.setText("If the accessibility settings indicate that this is a restricted setting, go to the application settings, tap the three dots in the upper right corner and then tap \"allow restricted settings\".");
		}
		root.addView(t3, lp);

		Button b2 = new Button(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			b2.setText("Перейти в настройки приложения");
		} else {
			b2.setText("Open application settings");
		}
		root.addView(b2, lp);
		b2.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					startActivity(
						new Intent(
							android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
							android.net.Uri.fromParts(
								"package",
								getApplicationContext().getPackageName(),
								null
							)
						)
					);
				}
			});

		TextView t4 = new TextView(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			t4.setText("Затем снова перейдите в настройки спецвозможностей и включите их для нашего приложения.");
		} else {
			t4.setText("Then return again to the accessibility settings and enable them for our application.");
		}
		root.addView(t4, lp);

		Button b3 = new Button(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			b3.setText("Перейти в настройки спецвозможностей");
		} else {
			b3.setText("Open accessibility settings");
		}
		root.addView(b3, lp);
		b3.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					startActivity(
						new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
					);
				}
			});

		TextView t5 = new TextView(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			t5.setText("Если не хотите использовать спецвозможности и не хотите возвращаться в лаунчер при открытии приложений в обход него, то нажмите сюда:");
		} else {
			t5.setText("If you do not want to use accessibility features and do not want to return to the launcher when applications are opened bypassing it, tap here:");
		}
		root.addView(t5, lp);

		Button b4 = new Button(this);
		if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
			b4.setText("Не хочу использовать спецвозможности");
		} else {
			b4.setText("I do not want to use accessibility features");
		}
		root.addView(b4, lp);
		b4.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					prefs.edit()
						.putBoolean("skip_accessibility", true)
						.apply();

					if (accessibilityDialog != null && accessibilityDialog.isShowing()) {
						accessibilityDialog.dismiss();
						accessibilityDialog = null;
					}
					showMainScreen();
				}
			});

		accessibilityDialog =
			new android.app.AlertDialog.Builder(this)
			.setTitle(
            getResources().getConfiguration().locale.getLanguage().equals("ru")
			? "Требуются спецвозможности"
			: "Accessibility permissions required"
        )
			.setView(root)
			.setCancelable(false)
			.create();

		accessibilityDialog.show();
	}

	private void setCode() {
		accessCode = prefs.getString("access_code", null);
		if (accessCode == null) {
			showed = true;
			android.app.AlertDialog.Builder builder =
				new android.app.AlertDialog.Builder(this);

			if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
				builder.setTitle("Задайте код доступа.");
				builder.setMessage("Он потом вам пригодится чтобы вводить \"код=\" в калькуляторе и смотреть скрытые приложения (по умолчанию все скрыты). Чтобы выбрать отображаемые нужно будет нажать на первый значёк в списке скрытых (шестеренку) и выбрать их там.");
			} else {
				builder.setTitle("Set an access code.");
				builder.setMessage(
					"You will later need this code to enter \"code=\" in the calculator and view hidden applications (by default all applications are hidden). To choose the visible apps, you will need to press the first icon in the hidden applications list (the gearwheel icon) and select them there."
				);
			}

			final android.widget.EditText input = new android.widget.EditText(this);
			input.setInputType(
				android.text.InputType.TYPE_CLASS_NUMBER |
				android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
			);
			if (getResources().getConfiguration().locale.getLanguage().equals("ru")) {
				input.setHint("Введите числовой код");
			} else {
				input.setHint("Enter numeric code");
			}
			builder.setView(input);

			builder.setPositiveButton(
				getResources().getConfiguration().locale.getLanguage().equals("ru")
                ? "Сохранить"
                : "Save",
				new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						String code = input.getText().toString().trim();
						if (!code.isEmpty()) {
							prefs.edit().putString("access_code", code).apply();
							accessCode = code;
							showed = false;
						} else {
							android.widget.Toast.makeText(
								MainActivity.this,
								getResources().getConfiguration().locale.getLanguage().equals("ru")
                                ? "Код не может быть пустым"
                                : "The code cannot be empty",
								android.widget.Toast.LENGTH_SHORT
							).show();
							setCode();
						}
					}
				}
			);

			builder.setNegativeButton(
				getResources().getConfiguration().locale.getLanguage().equals("ru")
                ? "Отмена"
                : "Cancel",
				new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						showed = false;
						dialog.cancel();
					}
				}
			);

			builder.show();
		}
	}


	private void showCalculatorScreen() {

		grid.removeAllViews();
		appTiles.clear();

		LinearLayout calcLayout = new LinearLayout(this);
		calcLayout.setOrientation(LinearLayout.VERTICAL);
		int padding = dpToPx(16);
		calcLayout.setPadding(padding, padding, padding, padding);

		final TextView display = new TextView(this);
		display.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);
		display.setGravity(Gravity.END);
		display.setBackgroundColor(Color.LTGRAY);
		display.setPadding(padding, padding, padding, padding);
		display.setText("");
		calcLayout.addView(display, new LinearLayout.LayoutParams(
							   LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(64)));

		GridLayout buttonsGrid = new GridLayout(this);
		buttonsGrid.setColumnCount(4);
		buttonsGrid.setUseDefaultMargins(true);

		final String[] buttons = {
			"7", "8", "9", "/",
			"4", "5", "6", "*",
			"1", "2", "3", "-",
			"0", "C", "=", "+"
		};

		final StringBuilder input = new StringBuilder();

		int screenW = getResources().getDisplayMetrics().widthPixels;

// ширина кнопки = 1/5 экрана
		int btnW = screenW / 5;

// сохраняем пропорцию (прямоугольник)
		int btnH = (int)(btnW * 0.65f);

		for (final String b : buttons) {

			Button btn = new Button(this);
			btn.setText(b);
			btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);

			GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
			lp.width = btnW;
			lp.height = btnH;
			btn.setLayoutParams(lp);

			btn.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						if (b.equals("C")) {
							input.setLength(0);
							display.setText("");
						} else if (b.equals("=")) {
							String code = input.toString();
							if (accessCode != null && accessCode.equals(code)) {
								showHiddenAppsScreen();
							} else {
								try {
									double result = evalExpression(code);
									display.setText(String.valueOf(result));
									input.setLength(0);
									input.append(result);
								} catch (Exception e) {
									display.setText("Ошибка");
									input.setLength(0);
								}
							}
						} else {
							input.append(b);
							display.setText(input.toString());
						}
					}
				});

			buttonsGrid.addView(btn);
		}

		calcLayout.addView(buttonsGrid);

		grid.addView(calcLayout);
	}

	private double evalExpression(String expr) throws Exception {
		expr = expr.replaceAll("[^0-9.+\\-*/]", "");
		if (expr.isEmpty()) return 0;

		if (expr.contains("+")) {
			String[] parts = expr.split("\\+");
			return Double.parseDouble(parts[0]) + Double.parseDouble(parts[1]);
		} else if (expr.contains("-")) {
			String[] parts = expr.split("\\-");
			return Double.parseDouble(parts[0]) - Double.parseDouble(parts[1]);
		} else if (expr.contains("*")) {
			String[] parts = expr.split("\\*");
			return Double.parseDouble(parts[0]) * Double.parseDouble(parts[1]);
		} else if (expr.contains("/")) {
			String[] parts = expr.split("/");
			return Double.parseDouble(parts[0]) / Double.parseDouble(parts[1]);
		} else {
			return Double.parseDouble(expr);
		}
	}

	private void showMainScreen() {    

	    accessCode = prefs.getString("access_code", null);
		if (accessCode == null && showed == false) {
			setCode();
		}

		grid.removeAllViews();    

		appTiles.clear();    

		// Добавляем калькулятор (эмодзи) как ярлык    
		Drawable calcIcon = generateCalculatorIconPro(1024);
		LinearLayout calcTile = createAppTile(
			calcIcon,
			getResources().getConfiguration().locale.getLanguage().equals("ru")
			? "Калькулятор"
			: "Calculator"
		);
		calcTile.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					accessCode = prefs.getString("access_code", null);
					if (accessCode == null) {
						setCode();
					}
					showCalculatorScreen();
				}
			});
		grid.addView(calcTile);    

		Intent intent = new Intent(Intent.ACTION_MAIN, null);    
		intent.addCategory(Intent.CATEGORY_LAUNCHER);    
		List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);    

		for (final ResolveInfo info : apps) {    
			final String pkg = info.activityInfo.packageName;    

			if (!whitelist.contains(pkg)) continue; // Только белые    

			Drawable icon = info.loadIcon(pm);    
			String label = info.loadLabel(pm).toString();    

			LinearLayout tile = createAppTile(icon, label);    
			tile.setOnClickListener(new View.OnClickListener() {    
					@Override    
					public void onClick(View v) {    
						Intent i = pm.getLaunchIntentForPackage(pkg);    
						if (i != null) {    
							lastPackage = "PreAllowed";
							startActivity(i);    
						}    
					}    
				});    

			appTiles.put(pkg, tile);    
			grid.addView(tile);    
		}    
	}    

	private void showHiddenAppsScreen() {    
		grid.removeAllViews();    
		appTiles.clear();    

		Intent intent = new Intent(Intent.ACTION_MAIN, null);    
		intent.addCategory(Intent.CATEGORY_LAUNCHER);    
		List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);    

		// Добавляем ярлык управления видимыми    
		LinearLayout manageVisibleTile = createAppTile(
			"⚙️",
			getResources().getConfiguration().locale.getLanguage().equals("ru")
			? "Управление видимыми"
			: "Visible management"
		);
		manageVisibleTile.setOnClickListener(new View.OnClickListener() {    
				@Override    
				public void onClick(View v) {    
					showManageVisibleListScreen();    
				}    
			});    
		grid.addView(manageVisibleTile);    

		for (final ResolveInfo info : apps) {    
			final String pkg = info.activityInfo.packageName;    

			if (whitelist.contains(pkg)) continue; // Только скрытые    

			Drawable icon = info.loadIcon(pm);    
			String label = info.loadLabel(pm).toString();    

			LinearLayout tile = createAppTile(icon, label);    
			tile.setOnClickListener(new View.OnClickListener() {    
					@Override    
					public void onClick(View v) {    
						Intent i = pm.getLaunchIntentForPackage(pkg);    
						if (i != null) {    
							lastPackage = "allowed";
							startActivity(i);    
							showMainScreen(); // Возвращаемся на главный экран    
						}    
					}    
				});    

			appTiles.put(pkg, tile);    
			grid.addView(tile);    
		}    
	}    

	private void showManageVisibleListScreen() {  
		grid.removeAllViews();  
		appTiles.clear();  

		Intent intent = new Intent(Intent.ACTION_MAIN, null);  
		intent.addCategory(Intent.CATEGORY_LAUNCHER);  
		List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);  

		for (final ResolveInfo info : apps) {  
			final String pkg = info.activityInfo.packageName;  

			Drawable icon = info.loadIcon(pm);  
			String label = info.loadLabel(pm).toString();  

			final LinearLayout tile = createAppTile(icon, label);  
			tile.setOnClickListener(new View.OnClickListener() {  
					@Override  
					public void onClick(View v) {  
						if (whitelist.contains(pkg)) {  
							whitelist.remove(pkg);  
						} else {  
							whitelist.add(pkg);  
						}  
						updateHighlights();  
					}  
				});  

			appTiles.put(pkg, tile);  
			grid.addView(tile);  
		}  

		// Добавляем кнопку "Сохранить список видимых"  
		TextView saveBtn = new TextView(this);  
		saveBtn.setText(
			getResources().getConfiguration().locale.getLanguage().equals("ru")
			? "Сохранить список видимых"
			: "Save visible list"
		);
		saveBtn.setTextColor(Color.WHITE);  
		saveBtn.setBackgroundColor(Color.DKGRAY);  
		saveBtn.setGravity(Gravity.CENTER);  
		int pad = dpToPx(12);  
		saveBtn.setPadding(pad, pad, pad, pad);  
		GridLayout.LayoutParams params = new GridLayout.LayoutParams();  
		params.width = GridLayout.LayoutParams.MATCH_PARENT;  
		params.height = GridLayout.LayoutParams.WRAP_CONTENT;  
		params.columnSpec = GridLayout.spec(0, grid.getColumnCount()); // Кнопка на всю ширину  
		params.setMargins(pad, pad, pad, pad);  
		saveBtn.setLayoutParams(params);  

		saveBtn.setOnClickListener(new View.OnClickListener() {  
				@Override  
				public void onClick(View v) {  
					prefs.edit().putStringSet("whitelist", whitelist).apply();  
					showMainScreen();  
				}  
			});  

		grid.addView(saveBtn);  

		updateHighlights();  
	}  

	private void updateHighlights() {    
		for (Map.Entry<String, LinearLayout> entry : appTiles.entrySet()) {    
			String pkg = entry.getKey();    
			LinearLayout tile = entry.getValue();    
			if (whitelist.contains(pkg)) {    
				tile.setBackgroundColor(Color.RED);    
			} else {    
				tile.setBackgroundColor(Color.TRANSPARENT);    
			}    
		}    
	}    


	private LinearLayout createAppTile(Object iconObj, String label) {

		LinearLayout tile = new LinearLayout(this);
		tile.setOrientation(LinearLayout.VERTICAL);
		tile.setGravity(Gravity.CENTER);

		// ====== ВАЖНО: считаем от DisplayMetrics ======
		int screenWidthPx = getResources().getDisplayMetrics().widthPixels;

		int columns = 4;
		int tileSizePx = screenWidthPx / columns;

		GridLayout.LayoutParams params = new GridLayout.LayoutParams();
		params.width = tileSizePx;
		params.height = tileSizePx;
		params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED);
		tile.setLayoutParams(params);

		// небольшой внутренний отступ (НЕ margin)
		int innerPad = tileSizePx / 10;
		tile.setPadding(innerPad, innerPad, innerPad, innerPad);

		LinearLayout.LayoutParams iconParams =
            new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			tileSizePx /2
		);
		iconParams.gravity = Gravity.CENTER;

		if (iconObj instanceof String) {
			TextView emoji = new TextView(this);
			emoji.setText((String) iconObj);
			emoji.setTextSize(TypedValue.COMPLEX_UNIT_PX, tileSizePx / 2);
			emoji.setGravity(Gravity.CENTER);
			emoji.setIncludeFontPadding(false);
			emoji.setLayoutParams(iconParams);
			tile.addView(emoji);
		} else if (iconObj instanceof Drawable) {
			ImageView iconView = new ImageView(this);
			iconView.setImageDrawable((Drawable) iconObj);
			iconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
			iconView.setLayoutParams(iconParams);
			tile.addView(iconView);
		}

		TextView labelView = new TextView(this);
		labelView.setText(label);
		labelView.setMaxLines(1);
		labelView.setGravity(Gravity.CENTER);
		labelView.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            tileSizePx / 11
		);

		tile.addView(labelView);

		return tile;
	}
	
	private Drawable generateCalculatorIconPro(int sizePx) {

		Bitmap bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888);
		Canvas c = new Canvas(bmp);

		Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
		Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

		text.setColor(Color.WHITE);
		text.setTextAlign(Paint.Align.CENTER);
		text.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

		float half = sizePx / 2f;

		// ==== ЦВЕТА КАК У GOOGLE ====
		int grayLight = Color.parseColor("#8E9399");
		int grayDark  = Color.parseColor("#3C4043");
		int grayMid   = Color.parseColor("#5F6368");
		int blue      = Color.parseColor("#4285F4");

		// ==== ФОНЫ ====
		p.setColor(grayLight); // -
		c.drawRect(0, 0, half, half, p);

		p.setColor(grayDark); // ×
		c.drawRect(half, 0, sizePx, half, p);

		p.setColor(grayMid); // +
		c.drawRect(0, half, half, sizePx, p);

		p.setColor(blue); // =
		c.drawRect(half, half, sizePx, sizePx, p);

		// ==== ТЕКСТ ====
		text.setTextSize(sizePx * 0.32f);

		Paint.FontMetrics fm = text.getFontMetrics();
		float yOffset = (fm.descent - fm.ascent) / 2f - fm.descent;

		// -
		c.drawText("−", half / 2f, half / 2f + yOffset, text);

		// ×
		c.drawText("×", half + half / 2f, half / 2f + yOffset, text);

		// +
		c.drawText("+", half / 2f, half + half / 2f + yOffset, text);

		// =
		c.drawText("=", half + half / 2f, half + half / 2f + yOffset, text);

		return new BitmapDrawable(getResources(), bmp);
	}
	
	private int dpToPx(int dp) {    
		float density = getResources().getDisplayMetrics().density;    
		return (int) (dp * density + 0.5f);    
	}  

}
