package ex.sandbox.launcher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;

public class SandboxAccessibilityService extends AccessibilityService {

    private BroadcastReceiver screenReceiver;
    private boolean waitForUnlock = false;
	private String lastForegroundPackage = null;
	private String preAllowedPackage = null;

	
    @Override
    public void onServiceConnected() {
        super.onServiceConnected();

        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
		
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 0;
        setServiceInfo(info);

        screenReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                    waitForUnlock = true;
                }
            }
        };

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screenReceiver, f);
    }

	
	@Override
	public void onAccessibilityEvent(AccessibilityEvent event) {

		if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
			return;
		}

		if (event.getPackageName() == null) {
			return;
		}

		String pkg = event.getPackageName().toString();

		// ================================
		// 0. ИГНОРИРУЕМ АКТИВНУЮ КЛАВИАТУРУ
		// ================================
		String ime = Settings.Secure.getString(
            getContentResolver(),
            Settings.Secure.DEFAULT_INPUT_METHOD
		);
		if (ime != null) {
			int slash = ime.indexOf('/');
			if (slash > 0 && ime.substring(0, slash).equals(pkg)) {
				return;
			}
		}

		// ================================
		// УТИЛИТА: ПРОВЕРКА UNLOCK
		// ================================
		KeyguardManager km =
            (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
		boolean unlocked = km != null && !km.isKeyguardLocked();

		// ================================
		// 1. ПОСЛЕ SCREEN_ON → ЖДЁМ UNLOCK
		// ================================
		if (waitForUnlock) {
			if (!unlocked) {
				// экран ещё заблокирован — НИЧЕГО НЕ ДЕЛАЕМ
				return;
			}

			// экран разблокирован → жёсткий возврат домой
			waitForUnlock = false;

			MainActivity.lastPackage = "abcd123";
			preAllowedPackage = null;
			lastForegroundPackage = null;

			performGlobalAction(GLOBAL_ACTION_HOME);
			return;
		}

		// ================================
		// 2. АБСОЛЮТНЫЙ РЕЖИМ (abcd123)
		// ================================
		if ("abcd123".equals(MainActivity.lastPackage)) {
			if (unlocked) {
				performGlobalAction(GLOBAL_ACTION_HOME);
			}
			return;
		}

		// ================================
		// 3. PREALLOWED — ОДИН ПАКЕТ
		// ================================
		if ("PreAllowed".equals(MainActivity.lastPackage)) {

			// первое окно разрешённого приложения
			if (preAllowedPackage == null && !pkg.equals(getPackageName())) {
				preAllowedPackage = pkg;
				lastForegroundPackage = pkg;
				return;
			}

			// activity внутри того же пакета
			if (pkg.equals(preAllowedPackage)) {
				lastForegroundPackage = pkg;
				return;
			}

			// ❌ любой другой пакет → ТОЛЬКО ЕСЛИ UNLOCK
			MainActivity.lastPackage = "abcd123";
			preAllowedPackage = null;
			lastForegroundPackage = null;

			if (unlocked) {
				performGlobalAction(GLOBAL_ACTION_HOME);
			}
			return;
		}

		// ================================
		// 4. ВОЗВРАТ В ЛАУНЧЕР → СБРОС
		// ================================
		if (pkg.equals(getPackageName())) {
			preAllowedPackage = null;
			lastForegroundPackage = pkg;
			return;
		}

		// ================================
		// 5. ОБЫЧНЫЙ РЕЖИМ
		// ================================
		lastForegroundPackage = pkg;
	}
	
    @Override
    public void onInterrupt() {
        // не требуется
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (screenReceiver != null) {
            unregisterReceiver(screenReceiver);
            screenReceiver = null;
        }
    }
}
